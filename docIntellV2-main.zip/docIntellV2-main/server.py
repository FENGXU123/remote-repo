
import os
import io
import time
import hashlib
import json
from flask import Flask, request, jsonify, make_response, send_from_directory
from flask_cors import CORS
from azure.core.credentials import AzureKeyCredential
from azure.ai.documentintelligence import DocumentIntelligenceClient
from azure.ai.documentintelligence.models import AnalyzeOutputOption
from dotenv import load_dotenv
from openai import AzureOpenAI

# Load environment variables
load_dotenv()

# --- Configuration ---
# Doc Intelligence
AZURE_DI_ENDPOINT = os.getenv("AZURE_DI_ENDPOINT")
AZURE_DI_KEY = os.getenv("AZURE_DI_KEY")

# OpenAI
AZURE_OPENAI_ENDPOINT = os.getenv("AZURE_OPENAI_ENDPOINT")
AZURE_OPENAI_KEY = os.getenv("AZURE_OPENAI_KEY")
AZURE_OPENAI_DEPLOYMENT = os.getenv("AZURE_OPENAI_DEPLOYMENT")
AZURE_OPENAI_API_VERSION = os.getenv("AZURE_OPENAI_API_VERSION", "2024-05-01-preview")

CACHE_DIR = "cache"

# --- Initialization ---
app = Flask(__name__)
CORS(app) 

if not os.path.exists(CACHE_DIR):
    os.makedirs(CACHE_DIR)

# Init Doc Intelligence
try:
    if not AZURE_DI_KEY or not AZURE_DI_ENDPOINT:
        print("WARNING: Azure DI credentials not found.")
        document_client = None
    else:
        document_client = DocumentIntelligenceClient(AZURE_DI_ENDPOINT, AzureKeyCredential(AZURE_DI_KEY))
        print("Azure Document Intelligence Client initialized.")
except Exception as e:
    print(f"ERROR: Failed to initialize Document Intelligence client: {e}")
    document_client = None

# Init Azure OpenAI
try:
    if not AZURE_OPENAI_KEY or not AZURE_OPENAI_ENDPOINT:
        print("WARNING: Azure OpenAI credentials not found.")
        openai_client = None
    else:
        openai_client = AzureOpenAI(
            api_key=AZURE_OPENAI_KEY,
            api_version=AZURE_OPENAI_API_VERSION,
            azure_endpoint=AZURE_OPENAI_ENDPOINT
        )
        print("Azure OpenAI Client initialized.")
except Exception as e:
    print(f"ERROR: Failed to initialize Azure OpenAI client: {e}")
    openai_client = None

# --- Constants ---
MODEL_LAYOUT = "prebuilt-layout"
MODEL_READ = "prebuilt-read"

@app.route('/')
def serve_index():
    return send_from_directory(os.getcwd(), 'docintell.html')

@app.route('/static/<path:path>')
def serve_static(path):
    return send_from_directory('static', path)

def generate_summary(text):
    """
    Generates a summary using Azure OpenAI.
    """
    if not openai_client or not AZURE_OPENAI_DEPLOYMENT:
        return "Summary unavailable (Configuration missing)."
    
    if not text or len(text) < 50:
        return "Content too short to summarize."

    try:
        response = openai_client.chat.completions.create(
            model=AZURE_OPENAI_DEPLOYMENT,
            messages=[
                {"role": "system", "content": "You are a helpful assistant. Summarize the following document content concisely in about 2-6 sentences in the well-structured format."},
                {"role": "user", "content": text[:15000]} # Truncate to avoid token limits for summary
            ],
            max_tokens=300
        )
        return response.choices[0].message.content.strip()
    except Exception as e:
        print(f"Summary Generation Error: {e}")
        return f"Failed to generate summary: {str(e)}"

def generate_qa(text):
    """
    Generates Q&A pairs using Azure OpenAI.
    Returns a list of dicts: [{"question": "...", "answer": "..."}]
    """
    if not openai_client or not AZURE_OPENAI_DEPLOYMENT:
        return []

    if not text or len(text) < 50:
        return []

    # Dynamic count: 3 to 8 questions based on length
    # e.g., 1 question every 2000 chars
    if len(text) < 1000:
        num_questions = 2
    else:
        num_questions = max(2, min(8, len(text) // 2000))
    
    try:
        response = openai_client.chat.completions.create(
            model=AZURE_OPENAI_DEPLOYMENT,
            messages=[
                {"role": "system", "content": f"""
                    You are a helpful assistant.

                    Generate exactly {num_questions} question–answer pairs based on the text provided.

                    Rules:
                    1. Output MUST be valid JSON.
                    2. Schema: {{ "qa_pairs": [ {{ "question": "...", "answer": "..." }}, ... ] }}
                    3. Questions must be under 15 words.
                    4. Answers must be concise (3-5 sentences).

                    Return ONLY the JSON object.
                    """},
                {"role": "user", "content": text[:35000]} 
            ],
            max_tokens=800,
            temperature=0.1,
            response_format={ "type": "json_object" } 
        )
        content = response.choices[0].message.content.strip()
        print(f"QA Response: {content[:100]}...") # Debug log

        # Parse JSON
        import json
        data = json.loads(content)
        
        # 1. Strict match for requested key
        if "qa_pairs" in data:
            return data["qa_pairs"]
            
        # 2. Fallbacks
        if isinstance(data, list):
            return data
        
        for key in ["pairs", "qa", "questions", "data"]:
            if key in data and isinstance(data[key], list):
                return data[key]

        # 3. Generic search for any list in values
        for val in data.values():
            if isinstance(val, list):
                return val
        
        return []
        
    except Exception as e:
        print(f"QA Generation Error: {e}")
        return []

@app.route('/analyze-document', methods=['POST'])
def analyze_document_endpoint():
    if document_client is None:
        return make_response(jsonify({"error": "Backend configuration error."}), 500)

    if 'file' not in request.files:
        return make_response(jsonify({"error": "No file part."}), 400)

    file = request.files['file']
    if file.filename == '':
        return make_response(jsonify({"error": "No selected file."}), 400)

    file_content = file.read()
    content_type = file.content_type
    filename = file.filename
    print(f"Analyzing: {filename}")

    # --- Caching Logic ---
    file_hash = hashlib.md5(file_content).hexdigest()
    cache_path = os.path.join(CACHE_DIR, f"{file_hash}.json")

    # Check Cache
    if os.path.exists(cache_path):
        print(f"Serving from cache: {filename}")
        with open(cache_path, 'r', encoding='utf-8') as f:
            cached_data = json.load(f)
            
            # Cache miss handling for new features (Summary & QA)
            updated = False
            
            if "summary" not in cached_data:
                print(f"Cache miss for summary: {filename}")
                cached_data["summary"] = generate_summary(cached_data.get("markdown", ""))
                updated = True
            
            if "qa_pairs" not in cached_data:
                print(f"Cache miss for QA: {filename}")
                cached_data["qa_pairs"] = generate_qa(cached_data.get("markdown", ""))
                updated = True

            if updated:
                with open(cache_path, 'w', encoding='utf-8') as fw:
                    json.dump(cached_data, fw)
                    
            return jsonify(cached_data)

    # Determine Model
    if content_type == "application/pdf":
        model_id = MODEL_LAYOUT
        output_options = {"output_content_format": "markdown", "output": [AnalyzeOutputOption.FIGURES]}
    else:
        model_id = MODEL_READ
        output_options = {"output_content_format": "markdown"}
    
    try:
        # Analyze
        if model_id == MODEL_LAYOUT:
            poller = document_client.begin_analyze_document(
                model_id=model_id, body=io.BytesIO(file_content), content_type="application/octet-stream", **output_options
            )
        else:
            poller = document_client.begin_analyze_document(model_id=model_id, body=io.BytesIO(file_content))

        result = poller.result()
        markdown_content = result.content
        print(len(markdown_content))
        
        if not markdown_content:
             markdown_content = f"## Analysis Result for {filename}\n\nNo text content extracted."

        # Parallel Generation (Sequential here for simplicity, can be threaded)
        summary = generate_summary(markdown_content)
        qa_pairs = generate_qa(markdown_content)

        response_data = {
            "filename": filename,
            "markdown": markdown_content,
            "summary": summary,
            "qa_pairs": qa_pairs,
            "status": "succeeded",
            "model_id": model_id
        }

        # Save to cache
        with open(cache_path, 'w', encoding='utf-8') as f:
            json.dump(response_data, f)

        return jsonify(response_data)

    except Exception as e:
        print(f"Analysis Error: {e}")
        return make_response(jsonify({"error": str(e), "status": "failed"}), 500)

if __name__ == '__main__':
    # Binds to 0.0.0.0 so the server is accessible by other devices on your LAN.
    print("Starting Flask server. Find your local IP address (e.g., 192.168.1.5:5001) to share the URL.")
    app.run(host='0.0.0.0', debug=True, port=5001)