
/**
 * Uploads a single file to the Python backend for analysis.
 * @param {File} file - The file object to upload.
 * @param {string} backendUrl - The URL of the analyze endpoint.
 * @returns {Promise<string>} - The markdown result.
 */
async function analyzeSingleFile(file, backendUrl) {
    const formData = new FormData();
    formData.append('file', file);

    const response = await fetch(backendUrl, {
        method: 'POST',
        body: formData
    });

    if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        throw new Error(errorData.error || `Server Error: ${response.status}`);
    }

    const data = await response.json();
    return data; // Return full object { markdown, summary, model_id, ... }
}

/**
 * Uploads an image to Dify for use in chat.
 * @param {File} file - The image file.
 * @param {object} config - Contains difyUrl and difyKey.
 * @returns {Promise<string|null>} - The uploaded file ID or null on failure.
 */
async function uploadImageToDify(file, config) {
    try {
        const formData = new FormData();
        formData.append('file', file);
        formData.append('user', 'doc-intel-user');

        const response = await fetch(`${config.difyUrl}/files/upload`, {
            method: 'POST',
            headers: { 'Authorization': `Bearer ${config.difyKey}` },
            body: formData
        });

        const data = await response.json();
        if (data.id) return data.id;
        return null;
    } catch (e) {
        console.error("Dify Upload Error:", e);
        return null;
    }
}

/**
 * Sends a chat message to Dify.
 * @param {object} payload - The chat payload.
 * @param {object} config - Contains difyUrl and difyKey.
 * @returns {Promise<Response>} - The fetch response object (stream).
 */
async function sendDifyMessage(payload, config) {
    return fetch(`${config.difyUrl}/chat-messages`, {
        method: 'POST',
        headers: {
            'Authorization': `Bearer ${config.difyKey}`,
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(payload)
    });
}
