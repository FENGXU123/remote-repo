
// --- Backend Connection Logic ---
const currentHost = window.location.hostname;
let BACKEND_URL;
if (currentHost === '127.0.0.1' || currentHost === 'localhost' || currentHost.startsWith('file://')) {
    BACKEND_URL = `http://127.0.0.1:5001/analyze-document`;
} else {
    BACKEND_URL = `${window.location.protocol}//${currentHost}/analyze-document`;
}
if (document.getElementById('backend-url-display')) {
    document.getElementById('backend-url-display').textContent = BACKEND_URL;
}

// --- State Management ---
const state = {
    files: [], // Array of File objects
    analyzedData: [], // Array of { filename, markdown, difyImageId(optional), fileObj(raw) }
    config: {
        difyKey: "",
        difyUrl: "https://api.dify.ai/v1"
    },
    difyConversationId: null,
    mentionActive: false,
    savedRange: null // Added to track cursor position
};

// --- DOM Elements ---
const els = {
    dropZone: document.getElementById('drop-zone'),
    fileInput: document.getElementById('file-upload'),
    fileListSection: document.getElementById('file-list-section'),
    fileListContainer: document.getElementById('file-list-container'),
    clearAllBtn: document.getElementById('clear-all-btn'),
    analyzeBtn: document.getElementById('analyze-btn'),

    // Modal
    settingsBtn: document.getElementById('settings-btn'),
    modal: document.getElementById('settings-modal'),
    previewModal: document.getElementById('preview-modal'),
    previewContent: document.getElementById('preview-content'),
    previewTitle: document.getElementById('preview-title'),
    modalClose: document.querySelectorAll('.modal-close, .modal-overlay, .modal-save'),
    difyKeyInput: document.getElementById('dify-key-input'),
    difyUrlInput: document.getElementById('dify-url-input'),

    // Tabs
    tabBtns: document.querySelectorAll('.tab-btn'),
    tabContents: document.querySelectorAll('.tab-content'),

    // Results
    emptyState: document.getElementById('empty-state'),
    loadingState: document.getElementById('loading-state'),
    loadingText: document.getElementById('loading-text'),
    progressBar: document.getElementById('progress-bar'),
    resultsContent: document.getElementById('results-content'),

    // Chat
    chatHistory: document.getElementById('chat-history'),
    chatInput: document.getElementById('chat-input'),
    sendChatBtn: document.getElementById('send-chat-btn'),
    newChatBtn: document.getElementById('new-chat-btn'),
    suggestionMenu: document.getElementById('suggestion-menu'),
    suggestionList: document.getElementById('suggestion-list'),

    // Status
    statusArea: document.getElementById('status-area'),
    statusBox: document.getElementById('status-box'),
    statusText: document.getElementById('status-text')
};

// --- Initialization ---
const storedConfig = localStorage.getItem('doc_intel_config');
if (storedConfig) {
    const parsed = JSON.parse(storedConfig);
    state.config.difyKey = parsed.difyKey || "";
    state.config.difyUrl = parsed.difyUrl || "https://api.dify.ai/v1";
    if (els.difyKeyInput) els.difyKeyInput.value = state.config.difyKey;
    if (els.difyUrlInput) els.difyUrlInput.value = state.config.difyUrl;
}

// --- Event Listeners ---

// Modal Logic
const toggleModal = () => {
    const isActive = els.modal.classList.contains('opacity-0');
    els.modal.classList.toggle('opacity-0', !isActive);
    els.modal.classList.toggle('pointer-events-none', !isActive);
    document.body.classList.toggle('modal-active', isActive);
};

const closeAllModals = () => {
    els.modal.classList.add('opacity-0', 'pointer-events-none');
    els.previewModal.classList.add('opacity-0', 'pointer-events-none');
    document.body.classList.remove('modal-active');
};

els.settingsBtn.addEventListener('click', toggleModal);
els.modalClose.forEach(el => el.addEventListener('click', () => {
    // Only save config if closing settings modal
    if (!els.modal.classList.contains('opacity-0')) {
        state.config.difyKey = els.difyKeyInput.value;
        state.config.difyUrl = els.difyUrlInput.value.replace(/\/$/, "");
        localStorage.setItem('doc_intel_config', JSON.stringify(state.config));
    }
    closeAllModals();
}));

// File Upload
els.dropZone.addEventListener('click', () => els.fileInput.click());
els.fileInput.addEventListener('change', (e) => handleFilesSelect(e.target.files));
els.dropZone.addEventListener('dragover', (e) => {
    e.preventDefault();
    els.dropZone.classList.add('border-brand-500', 'bg-slate-50');
});
els.dropZone.addEventListener('dragleave', (e) => {
    e.preventDefault();
    els.dropZone.classList.remove('border-brand-500', 'bg-slate-50');
});
els.dropZone.addEventListener('drop', (e) => {
    e.preventDefault();
    els.dropZone.classList.remove('border-brand-500', 'bg-slate-50');
    if (e.dataTransfer.files.length) handleFilesSelect(e.dataTransfer.files);
});

els.clearAllBtn.addEventListener('click', clearFiles);
els.analyzeBtn.addEventListener('click', startBatchAnalysis);

// Tabs
els.tabBtns.forEach(btn => {
    btn.addEventListener('click', () => {
        els.tabBtns.forEach(b => {
            b.classList.remove('border-brand-600', 'text-brand-600');
            b.classList.add('border-transparent', 'text-slate-500');
        });
        els.tabContents.forEach(c => c.classList.add('hidden'));
        btn.classList.remove('border-transparent', 'text-slate-500');
        btn.classList.add('border-brand-600', 'text-brand-600');
        document.getElementById(`tab-${btn.dataset.tab}`).classList.remove('hidden');
    });
});

// Chat & Mention Logic
els.chatInput.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
        e.preventDefault();
        if (!state.mentionActive && !els.analyzeBtn.disabled) {
            sendChatMessage();
        }
    }
});

els.chatInput.addEventListener('input', (e) => {
    const selection = window.getSelection();
    if (!selection.rangeCount) return;

    const range = selection.getRangeAt(0);
    const textNode = range.startContainer;

    // We only care if we are in a text node
    if (textNode.nodeType === Node.TEXT_NODE) {
        const textBeforeCaret = textNode.textContent.substring(0, range.startOffset);
        const lastAt = textBeforeCaret.lastIndexOf('@');

        // Show suggestions if user typed '@' and hasn't finished (no space after yet)
        if (lastAt !== -1 && !textBeforeCaret.slice(lastAt).includes(' ')) {
            // Save the range so we can restore it when clicking the menu
            state.savedRange = range.cloneRange();

            if (state.analyzedData.length > 0) {
                showSuggestions();
            }
        } else {
            hideSuggestions();
        }
    } else {
        hideSuggestions();
    }

    // Toggle send button readability
    const isEmpty = els.chatInput.textContent.trim() === '';
    els.sendChatBtn.classList.toggle('text-slate-400', isEmpty);
    els.sendChatBtn.classList.toggle('text-brand-600', !isEmpty);
});

// Hide menu on click outside
document.addEventListener('click', (e) => {
    if (!els.suggestionMenu.contains(e.target) && !els.chatInput.contains(e.target)) {
        hideSuggestions();
    }
});

els.sendChatBtn.addEventListener('click', sendChatMessage);
els.newChatBtn.addEventListener('click', startNewChat);


// --- UI Functions ---

function startNewChat() {
    els.chatHistory.innerHTML = '';
    const welcomeHtml = `
        <div class="flex gap-3">
            <div class="w-8 h-8 rounded-full bg-brand-100 flex items-center justify-center flex-shrink-0">
                <i class="ph-fill ph-robot text-brand-600"></i>
            </div>
            <div class="bg-white p-3 rounded-lg rounded-tl-none border border-slate-200 shadow-sm max-w-[80%]">
                <p class="text-sm text-slate-700">New conversation started! Context cleared. Upload and analyze documents to chat.</p>
            </div>
        </div>
    `;
    els.chatHistory.innerHTML = welcomeHtml;
    state.difyConversationId = null;
    els.chatInput.textContent = ''; // Clear text
    els.chatInput.focus();
}

function handleFilesSelect(fileList) {
    if (!fileList || fileList.length === 0) return;

    Array.from(fileList).forEach(newFile => {
        const exists = state.files.some(f => f.name === newFile.name && f.size === newFile.size);
        if (!exists) {
            state.files.push(newFile);
        }
    });

    renderFileList();

    els.fileListSection.classList.remove('hidden');
    els.analyzeBtn.disabled = false;

    els.emptyState.classList.remove('hidden');
    els.resultsContent.classList.add('hidden');
    els.resultsContent.innerHTML = '';
    state.analyzedData = [];
    disableChat();
    updateStatus('Ready to analyze.', 'info');
}

function renderFileList() {
    els.fileListContainer.innerHTML = '';
    state.files.forEach((file, index) => {
        const item = document.createElement('div');
        item.className = 'bg-white border border-slate-200 rounded-lg shadow-sm p-2 flex items-center justify-between group cursor-pointer';

        let iconClass = "ph-duotone ph-file-text text-blue-500";
        if (file.type.includes('image')) iconClass = "ph-duotone ph-image text-purple-500";
        if (file.type.includes('pdf')) iconClass = "ph-duotone ph-file-pdf text-red-500";

        item.innerHTML = `
            <div class="flex items-center space-x-2 overflow-hidden">
                <i class="${iconClass} text-xl"></i>
                <div class="min-w-0">
                    <p class="text-xs font-medium text-slate-700 truncate">${file.name}</p>
                    <p class="text-[10px] text-slate-400">${(file.size / 1024 / 1024).toFixed(2)} MB</p>
                </div>
            </div>
            <button class="preview-file-btn text-slate-400 hover:text-brand-500 p-1 rounded transition-colors mr-1" data-index="${index}" title="Preview">
                <i class="ph-bold ph-eye"></i>
            </button>
            <button class="remove-file-btn text-slate-400 hover:text-red-500 p-1 rounded transition-colors" data-index="${index}" title="Remove">
                <i class="ph-bold ph-x"></i>
            </button>
        `;

        item.addEventListener('click', function (e) {
            if (e.target.closest('button')) return;
            const resultCard = document.getElementById(`result-${cssEscapeId(file.name)}`);
            if (resultCard) {
                resultCard.scrollIntoView({ behavior: 'smooth', block: 'start' });
                resultCard.classList.add('ring-2', 'ring-brand-500');
                setTimeout(() => resultCard.classList.remove('ring-2', 'ring-brand-500'), 1200);
            }
        });

        item.querySelector('.remove-file-btn').addEventListener('click', (e) => {
            e.stopPropagation();
            removeFile(index);
        });

        item.querySelector('.preview-file-btn').addEventListener('click', (e) => {
            e.stopPropagation();
            openPreview(index);
        });

        els.fileListContainer.appendChild(item);
    });
}

function openPreview(index) {
    const file = state.files[index];
    if (!file) return;

    els.previewTitle.textContent = file.name;
    els.previewContent.innerHTML = '';

    els.previewModal.classList.remove('opacity-0', 'pointer-events-none');
    document.body.classList.add('modal-active');

    const objectUrl = URL.createObjectURL(file);

    if (file.type.startsWith('image/')) {
        const img = document.createElement('img');
        img.src = objectUrl;
        img.className = "max-w-full max-h-full object-contain shadow-lg rounded";
        els.previewContent.appendChild(img);
    } else if (file.type === 'application/pdf') {
        const iframe = document.createElement('iframe');
        iframe.src = objectUrl;
        iframe.className = "w-full h-full border-none rounded shadow-lg bg-white";
        els.previewContent.appendChild(iframe);
    } else {
        els.previewContent.innerHTML = `
            <div class="text-center text-slate-500">
                <i class="ph-duotone ph-file-dashed text-6xl mb-4"></i>
                <p>Preview not available for this file type.</p>
                <p class="text-xs mt-2">${file.type}</p>
            </div>
        `;
    }
}

function cssEscapeId(str) {
    return str.replace(/[^a-zA-Z0-9\-_:.]/g, s => {
        return '_' + s.charCodeAt(0) + '_';
    });
}

function removeFile(index) {
    state.files.splice(index, 1);
    renderFileList();
    if (state.files.length === 0) clearFiles();
}

function clearFiles() {
    state.files = [];
    state.analyzedData = [];
    els.fileInput.value = '';
    els.fileListSection.classList.add('hidden');
    els.analyzeBtn.disabled = true;
    els.statusArea.classList.add('hidden');
    disableChat();
}

function updateStatus(msg, type) {
    els.statusArea.classList.remove('hidden');
    els.statusText.textContent = msg;
    els.statusBox.className = 'flex items-start p-3 text-sm rounded-lg border';
    if (type === 'error') els.statusBox.classList.add('bg-red-50', 'text-red-800', 'border-red-200');
    else if (type === 'success') els.statusBox.classList.add('bg-green-50', 'text-green-800', 'border-green-200');
    else els.statusBox.classList.add('bg-yellow-50', 'text-yellow-800', 'border-yellow-200');
}

// --- Suggestion Menu Logic ---

function showSuggestions() {
    state.mentionActive = true;
    els.suggestionMenu.classList.remove('hidden');
    els.suggestionList.innerHTML = '';

    state.analyzedData.forEach(item => {
        const div = document.createElement('div');
        div.className = 'px-4 py-2 hover:bg-brand-50 cursor-pointer flex items-center space-x-2 text-sm text-slate-700 transition-colors';
        div.innerHTML = `<i class="ph-bold ph-file"></i> <span class="truncate">${item.filename}</span>`;
        // Use mousedown to prevent focus loss before click
        div.onmousedown = (e) => {
            e.preventDefault(); // Prevent focus loss from input
            selectSuggestion(item.filename);
        };
        els.suggestionList.appendChild(div);
    });
}

function hideSuggestions() {
    state.mentionActive = false;
    els.suggestionMenu.classList.add('hidden');
}

function selectSuggestion(filename) {
    // Restore focus
    els.chatInput.focus();

    // access saved range
    if (!state.savedRange) return;

    const range = state.savedRange;
    const textNode = range.startContainer;
    const text = textNode.textContent;
    const offset = range.startOffset;

    // Find the @ symbol before cursor
    const beforeCursor = text.substring(0, offset);
    const atIndex = beforeCursor.lastIndexOf('@');

    if (atIndex !== -1 && textNode.parentNode) {
        // Separate text parts
        const beforeAt = text.substring(0, atIndex);
        const afterCursor = text.substring(offset); // If any

        // Create Mention Element
        const mentionSpan = document.createElement('span');
        // Changed style to be cleaner: White bg, brand text. Looks good on both input (slate-50) and User Bubble (red-300)
        mentionSpan.className = "bg-white text-brand-600 font-bold px-1.5 py-0.5 rounded shadow-sm mx-0.5 select-none text-xs align-middle";
        mentionSpan.contentEditable = "false";
        mentionSpan.textContent = `@${filename}`;
        mentionSpan.dataset.filename = filename;

        // Update text node to be just the part before @
        textNode.textContent = beforeAt;

        const parent = textNode.parentNode;
        const nextSibling = textNode.nextSibling;

        // 1. Insert Mention after the text node
        if (nextSibling) {
            parent.insertBefore(mentionSpan, nextSibling);
        } else {
            parent.appendChild(mentionSpan);
        }

        // 2. Insert Space after mention (new text node)
        const spaceNode = document.createTextNode('\u00A0'); // nbsp
        if (mentionSpan.nextSibling) {
            parent.insertBefore(spaceNode, mentionSpan.nextSibling);
        } else {
            parent.appendChild(spaceNode);
        }

        // 3. Insert remaining text if any
        if (afterCursor) {
            const afterNode = document.createTextNode(afterCursor);
            if (spaceNode.nextSibling) {
                parent.insertBefore(afterNode, spaceNode.nextSibling);
            } else {
                parent.appendChild(afterNode);
            }
        }

        // 4. Move caret to AFTER the space
        const newSelection = window.getSelection();
        const newRange = document.createRange();
        newRange.setStart(spaceNode, 1);
        newRange.collapse(true);
        newSelection.removeAllRanges();
        newSelection.addRange(newRange);
    }

    hideSuggestions();
    state.savedRange = null;
}

// --- Backend Analysis Phase ---

async function startBatchAnalysis() {
    els.analyzeBtn.disabled = true;
    els.analyzeBtn.innerHTML = '<i class="ph-bold ph-spinner animate-spin mr-2"></i> Analyzing...';
    els.emptyState.classList.add('hidden');
    els.resultsContent.classList.add('hidden');
    els.loadingState.classList.remove('hidden');
    els.tabBtns[0].click();

    state.analyzedData = [];

    const CONCURRENCY_LIMIT = 3;
    let completedCount = 0;

    const processFile = async (file) => {
        try {
            els.loadingText.textContent = `Processing files (${completedCount}/${state.files.length} completed)...`;
            // 1. Analyze Document
            const analysisResult = await analyzeSingleFile(file, BACKEND_URL);

            // Extract data from the full response object
            const markdownContent = analysisResult.markdown || "No content extracted.";
            const summaryContent = analysisResult.summary || null;
            const qaPairs = analysisResult.qa_pairs || [];
            const modelId = analysisResult.model_id || null;

            // 2. Just-In-Time Upload to Dify (if image and key present)
            let difyImageId = null;
            if (file.type.startsWith('image/') && state.config.difyKey) {
                // We do this serially per file, but multiple files are parallel
                difyImageId = await uploadImageToDify(file, state.config);
            }

            return {
                filename: file.name,
                markdown: markdownContent,
                summary: summaryContent,
                qa_pairs: qaPairs,
                model_id: modelId,
                difyImageId: difyImageId,
                fileObj: file,
                success: true
            };
        } catch (error) {
            console.error(`Error processing ${file.name}:`, error);
            return {
                filename: file.name,
                markdown: `> **Error**: Analysis failed. ${error.message}`,
                fileObj: file,
                success: false
            };
        } finally {
            completedCount++;
            const progress = Math.round((completedCount / state.files.length) * 100);
            els.progressBar.style.width = `${progress}%`;
            els.loadingText.textContent = `Processing files (${completedCount}/${state.files.length} completed)...`;
        }
    };

    try {
        const filesClone = [...state.files];
        const results = [];

        for (let i = 0; i < filesClone.length; i += CONCURRENCY_LIMIT) {
            const batch = filesClone.slice(i, i + CONCURRENCY_LIMIT);
            const batchResults = await Promise.all(batch.map(file => processFile(file)));
            results.push(...batchResults);
        }

        state.analyzedData = results;
        els.progressBar.style.width = `100%`;
        els.resultsContent.innerHTML = '';

        state.analyzedData.forEach(item => {
            const card = document.createElement('div');
            card.className = "bg-white p-0 rounded-xl shadow-sm border border-slate-200 markdown-body";
            card.id = `result-${cssEscapeId(item.filename)}`;

            // Collapsible header
            const header = document.createElement('div');
            header.className = "flex items-center justify-between border-b border-slate-100 px-6 py-4 cursor-pointer select-none";
            const statusColor = item.success ? 'text-brand-600' : 'text-red-500';
            header.innerHTML = `
                <h2 class="text-xl font-bold ${statusColor} !mt-0 !mb-0">${item.filename}</h2>
                <div class="flex items-center gap-2">
                    <span class="text-xs text-slate-400 font-normal">Model: ${item.model_id || 'N/A'}</span>
                    <button class="collapse-toggle text-slate-400 hover:text-brand-600 transition-colors bg-transparent border-0 cursor-pointer" aria-label="Toggle collapse">
                        <i class="ph-bold ph-caret-up text-lg"></i>
                    </button>
                </div>
            `;

            // Content Container (Grid Layout)
            const content = document.createElement('div');
            content.className = "result-content px-6 pb-6 pt-2";

            // Layout Decision: Split vs Full
            if (item.summary || (item.qa_pairs && item.qa_pairs.length > 0)) {
                // Split View: Content (left) | Sidebar (right)

                // Build Sidebar (QA Only)
                let sidebarHtml = "";
                // Build QA HTML
                if (item.qa_pairs && item.qa_pairs.length > 0) {
                    const qaCards = item.qa_pairs.map((qa, i) => `
                        <div class="qa-card bg-white border border-slate-200 rounded-lg p-4 cursor-pointer hover:shadow-md transition-all group mb-3" onclick="this.classList.toggle('expanded')">
                            <div class="flex justify-between items-start gap-3 select-none">
                                <div class="font-bold text-slate-700 text-sm leading-snug flex-grow pr-6 relative">
                                    <span class="absolute -right-1 top-0 opacity-0 group-hover:opacity-100 transition-opacity">
                                        <button class="text-slate-400 hover:text-brand-600 p-1 rounded-full hover:bg-slate-100" title="Copy Question" onclick="copyToClipboard('${qa.question.replace(/'/g, "\\'")}', this); event.stopPropagation();">
                                            <i class="ph-bold ph-copy"></i>
                                        </button>
                                    </span>
                                    ${qa.question}
                                </div>
                                <div class="text-slate-400 group-hover:text-brand-500 transition-colors flex-shrink-0">
                                    <i class="ph-bold ph-caret-down transform transition-transform duration-200 icon-expand"></i>
                                </div>
                            </div>
                            <div class="qa-answer hidden mt-3 pt-3 border-t border-slate-100 text-sm text-slate-600 leading-relaxed animate-fadeIn">
                                ${qa.answer}
                            </div>
                        </div>
                    `).join('');

                    sidebarHtml += `
                        <div>
                             <h3 class="text-sm font-bold text-slate-500 uppercase tracking-wider mb-2 flex items-center gap-2">
                                <i class="ph-fill ph-student text-brand-500"></i> Q&A
                            </h3>
                            <div class="qa-container bg-slate-50 p-4 rounded-xl border border-slate-200">
                                ${qaCards}
                            </div>
                        </div>
                    `;
                } else if (!item.summary) {
                    // Fallback specific: If no summary and no QA, this block won't be hit due to top if check logic, but safe to have empty sidebar
                }

                // Build Main Content (Summary + Content)
                let mainContentHtml = "";

                if (item.summary) {
                    mainContentHtml += `
                         <div class="mb-8">
                            <h3 class="text-sm font-bold text-slate-500 uppercase tracking-wider mb-2 flex items-center gap-2">
                                <i class="ph-fill ph-sparkle text-yellow-500"></i> AI Summary
                            </h3>
                            <div class="bg-brand-50 p-6 rounded-xl text-sm text-slate-700 leading-relaxed border border-brand-100 shadow-sm markdown-body">
                                ${marked.parse(item.summary)}
                            </div>
                        </div>
                    `;
                }

                mainContentHtml += `
                    <div>
                        <h3 class="text-base font-bold text-slate-800 uppercase tracking-wider mb-3 flex items-center gap-2">
                            <i class="ph-fill ph-article text-red-400"></i> Analysis Content:
                        </h3>
                        <div class="markdown-body border-r border-slate-100 pr-6 min-h-[300px]">
                            ${marked.parse(item.markdown)}
                        </div>
                    </div>
                `;

                content.innerHTML = `
                    <div class="grid grid-cols-1 lg:grid-cols-10 gap-8">
                        <!-- Main Column (70%) -->
                        <div class="lg:col-span-7">
                            ${mainContentHtml}
                        </div>
                        
                        <!-- Sidebar Column (30% - QA Only) -->
                        <div class="lg:col-span-3">
                             <div class="sticky top-4 max-h-[calc(100vh-8rem)] overflow-y-auto pr-2 custom-scrollbar">
                                ${sidebarHtml}
                            </div>
                        </div>
                    </div>
                `;
            } else {
                // Full Width (Fallback)
                content.innerHTML = `${marked.parse(item.markdown)}`;
            }

            let expanded = true;
            const toggle = () => {
                expanded = !expanded;
                content.style.display = expanded ? 'block' : 'none';
                const icon = header.querySelector('.collapse-toggle i');
                if (icon) icon.style.transform = expanded ? 'rotate(0deg)' : 'rotate(180deg)';
            };

            header.addEventListener('click', (e) => {
                // Toggle unless clicking other interactive elements
                if (e.target.closest('button') && !e.target.closest('.collapse-toggle')) return;
                toggle();
            });

            card.appendChild(header);
            card.appendChild(content);
            els.resultsContent.appendChild(card);
        });

        // Add CSS for QA toggle in a style tag if not present
        if (!document.getElementById('qa-styles')) {
            const style = document.createElement('style');
            style.id = 'qa-styles';
            style.textContent = `
                .qa-card.expanded .qa-answer { display: block; }
                .qa-card.expanded .icon-expand { transform: rotate(180deg); }
                .custom-scrollbar::-webkit-scrollbar { width: 4px; }
                .custom-scrollbar::-webkit-scrollbar-thumb { background: #cbd5e1; border-radius: 4px; }
                .custom-scrollbar::-webkit-scrollbar-track { background: transparent; }
                @keyframes fadeIn { from { opacity: 0; transform: translateY(-4px); } to { opacity: 1; transform: translateY(0); } }
            `;
            document.head.appendChild(style);
        }

        els.resultsContent.classList.remove('hidden');
        updateStatus(`Successfully analyzed ${state.files.length} documents.`, 'success');
        enableChat();

    } catch (err) {
        console.error(err);
        updateStatus(`Batch Error: ${err.message}`, 'error');
        els.emptyState.classList.remove('hidden');
    } finally {
        els.loadingState.classList.add('hidden');
        els.analyzeBtn.disabled = false;
        els.analyzeBtn.innerHTML = '<i class="ph-bold ph-lightning mr-2"></i> Re-Analyze All';
    }
}


// --- Dify Chat Phase ---

function enableChat() {
    if (!state.config.difyKey) {
        updateStatus('Analysis done. Configure Dify Key to chat.', 'warning');
        return;
    }
    els.chatInput.contentEditable = "true";
    els.sendChatBtn.disabled = false;
    els.chatInput.setAttribute("placeholder", "Ask or type @ to select files...");
}

function disableChat() {
    els.chatInput.contentEditable = "false";
    els.sendChatBtn.disabled = true;
    els.chatInput.setAttribute("placeholder", "Analyze a document to start chatting...");
    els.chatInput.textContent = '';
}

function addMessageToChat(role, text, isHtml = false) {
    const wrapper = document.createElement('div');
    wrapper.className = `flex gap-3 ${role === 'user' ? 'flex-row-reverse' : ''}`;

    const avatar = document.createElement('div');
    avatar.className = `w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 ${role === 'user' ? 'bg-blue-100 text-blue-500' : 'bg-brand-100 text-brand-600'}`;
    avatar.innerHTML = role === 'user' ? '<i class="ph-fill ph-user"></i>' : '<i class="ph-fill ph-robot"></i>';

    const bubble = document.createElement('div');
    bubble.className = `p-3 rounded-lg shadow-sm max-w-[80%] text-sm ${role === 'user' ? 'bg-blue-500 text-white rounded-tr-none' : 'bg-white border border-slate-200 text-slate-700 rounded-tl-none'}`;

    if (role === 'system') {
        bubble.innerHTML = marked.parse(text);
        bubble.classList.add('markdown-body');
    } else if (role === 'user' && isHtml) {
        bubble.innerHTML = text; // Render preserved HTML (mentions)
    } else {
        bubble.textContent = text;
    }

    wrapper.appendChild(avatar);
    wrapper.appendChild(bubble);
    els.chatHistory.appendChild(wrapper);
    els.chatHistory.scrollTop = els.chatHistory.scrollHeight;
}

async function sendChatMessage() {
    const rawText = els.chatInput.innerText.trim();
    if (!rawText || state.analyzedData.length === 0) return;

    // Capture the HTML content to preserve styling (mentions)
    const displayHtml = els.chatInput.innerHTML;

    let apiQuery = "";

    // Clean query for API: remove mention spans logic
    // We iterate specific nodes to build clean string
    els.chatInput.childNodes.forEach(node => {
        if (node.nodeType === Node.TEXT_NODE) {
            apiQuery += node.textContent;
        } else if (node.nodeType === Node.ELEMENT_NODE && node.tagName === 'BR') {
            apiQuery += '\n';
        }
        // skip mention spans
    });
    apiQuery = apiQuery.trim();
    if (!apiQuery) apiQuery = rawText;

    // Send styled message to chat
    addMessageToChat('user', displayHtml, true);
    els.chatInput.innerHTML = '';
    hideSuggestions();

    const loadingId = 'loading-' + Date.now();
    const loadingDiv = document.createElement('div');
    loadingDiv.id = loadingId;
    loadingDiv.className = "flex gap-3";
    loadingDiv.innerHTML = `<div class="w-8 h-8 rounded-full bg-brand-100 text-brand-600 flex items-center justify-center flex-shrink-0"><i class="ph-fill ph-robot"></i></div><div class="bg-white p-3 rounded-lg rounded-tl-none border border-slate-200 shadow-sm"><i class="ph-bold ph-dots-three animate-bounce"></i></div>`;
    els.chatHistory.appendChild(loadingDiv);
    els.chatHistory.scrollTop = els.chatHistory.scrollHeight;

    try {
        let targetFiles = [];

        state.analyzedData.forEach(data => {
            if (rawText.includes(`@${data.filename}`)) {
                targetFiles.push(data);
            }
        });

        if (targetFiles.length === 0) {
            targetFiles = state.analyzedData;
        }

        for (let item of targetFiles) {
            if (!item.difyImageId && item.fileObj && item.fileObj.type.startsWith('image/') && state.config.difyKey) {
                const uploadedId = await uploadImageToDify(item.fileObj, state.config);
                if (uploadedId) item.difyImageId = uploadedId;
            }
        }

        const fullContext = targetFiles.map(d => `--- START FILE: ${d.filename} ---\n${d.markdown}\n--- END FILE: ${d.filename} ---`).join('\n\n');

        const imageList = [];
        targetFiles.forEach(item => {
            if (item.difyImageId) {
                imageList.push({
                    type: "image",
                    transfer_method: "local_file",
                    upload_file_id: item.difyImageId
                });
            }
        });

        const payload = {
            inputs: {
                "analysis_result": fullContext,
                "images": imageList
            },
            query: apiQuery,
            response_mode: "streaming",
            user: "doc-intel-user",
            files: []
        };
        if (state.difyConversationId) payload.conversation_id = state.difyConversationId;

        const response = await sendDifyMessage(payload, state.config);

        document.getElementById(loadingId).remove();

        if (!response.ok) throw new Error("API Error: " + response.statusText);

        const wrapper = document.createElement('div');
        wrapper.className = `flex gap-3`;

        const avatar = document.createElement('div');
        avatar.className = `w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 bg-brand-100 text-brand-600`;
        avatar.innerHTML = '<i class="ph-fill ph-robot"></i>';

        const bubble = document.createElement('div');
        bubble.className = `p-3 rounded-lg shadow-sm max-w-[80%] text-sm bg-white border border-slate-200 text-slate-700 rounded-tl-none markdown-body`;
        bubble.innerHTML = '';

        wrapper.appendChild(avatar);
        wrapper.appendChild(bubble);
        els.chatHistory.appendChild(wrapper);

        const reader = response.body.getReader();
        const decoder = new TextDecoder();
        let fullText = "";

        if (reader) {
            while (true) {
                const { done, value } = await reader.read();
                if (done) break;

                const chunk = decoder.decode(value, { stream: true });
                const lines = chunk.split('\n');

                for (const line of lines) {
                    if (line.startsWith('data: ')) {
                        const jsonStr = line.substring(6).trim();
                        if (!jsonStr || jsonStr === '[DONE]') continue;
                        try {
                            const data = JSON.parse(jsonStr);
                            if (data.event === 'message' || data.event === 'agent_message') {
                                const text = data.answer;
                                fullText += text;
                                bubble.innerHTML = marked.parse(fullText);
                                els.chatHistory.scrollTop = els.chatHistory.scrollHeight;
                                if (data.conversation_id) state.difyConversationId = data.conversation_id;
                            } else if (data.event === 'error') {
                                bubble.innerHTML += `<br/><span class="text-red-500">[Error: ${data.message}]</span>`;
                            }
                        } catch (e) { }
                    }
                }
            }
        }

    } catch (err) {
        if (document.getElementById(loadingId)) document.getElementById(loadingId).remove();
        addMessageToChat('system', `Error: ${err.message}`);
    } finally {
        els.chatInput.contentEditable = "true";
        els.chatInput.focus();
    }
}

// Global copy function to be called from inline HTML
window.copyToClipboard = (text, btn) => {
    navigator.clipboard.writeText(text).then(() => {
        const originalHtml = btn.innerHTML;
        btn.innerHTML = '<i class="ph-bold ph-check text-green-500"></i>';
        setTimeout(() => {
            btn.innerHTML = originalHtml;
        }, 1500);
    }).catch(err => {
        console.error('Failed to copy: ', err);
    });
};
